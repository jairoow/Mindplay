import { RevealRing } from "../ui/ProgressBar.jsx";
import AnimatedSection from "../ui/AnimatedSection.jsx";

/**
 * Presenta visualmente un resultado ya calculado (título, tagline, descripción,
 * fortalezas, "lo que te define", lado menos bueno, frase final y, opcionalmente,
 * estadísticas / lista de películas / aviso legal). No depende de las respuestas
 * concretas: todo lo que necesita vive en `result`, por eso el resultado es 100%
 * reconstruible desde la URL /resultado/:test/:key.
 *
 * Cada bloque entra en pantalla con una aparición suave (fade + slide) al hacer
 * scroll, vía AnimatedSection — sin librerías de animación externas.
 */
export default function ResultCard({ result }) {
  return (
    <div className="result-hero">
      {result.emoji && (
        <div className="result-hero__emoji" aria-hidden="true">
          {result.emoji}
        </div>
      )}
      <div className="eyebrow result-hero__eyebrow">Tu resultado</div>
      <h1 className="result-hero__title">{result.title}</h1>
      {result.tagline && <p className="result-hero__tagline">{result.tagline}</p>}

      <div className="result-hero__ring">
        <RevealRing value={result.matchPercent ?? 100} size={140} />
      </div>

      <p className="result-hero__description">{result.description}</p>

      {result.strengths?.length > 0 && (
        <AnimatedSection className="result-block" delay={40}>
          <h2 className="result-block__title">Tus fortalezas</h2>
          <ul className="result-traits__list result-traits__list--positive">
            {result.strengths.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </AnimatedSection>
      )}

      {result.sections?.length > 0 && (
        <AnimatedSection className="result-block" delay={100}>
          <h2 className="result-block__title">Lo que te define</h2>
          <div className="result-sections">
            {result.sections.map((section) => (
              <div className="result-section" key={section.heading}>
                <h3 className="result-section__heading">{section.heading}</h3>
                <p className="result-section__text">{section.text}</p>
              </div>
            ))}
          </div>
        </AnimatedSection>
      )}

      {result.weaknesses?.length > 0 && (
        <AnimatedSection className="result-block" delay={160}>
          <h2 className="result-block__title">{result.weaknessesLabel || "Tu lado menos bueno"}</h2>
          <p className="result-block__hint">Nadie es perfecto. Por suerte, esto tiene su encanto.</p>
          <ul className="result-traits__list result-traits__list--caution">
            {result.weaknesses.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </AnimatedSection>
      )}

      {result.movieList?.length > 0 && (
        <AnimatedSection className="result-block" delay={200}>
          <h2 className="result-block__title">Te podrían gustar</h2>
          <ul className="result-movie-list">
            {result.movieList.map((movie) => (
              <li key={movie}>{movie}</li>
            ))}
          </ul>
        </AnimatedSection>
      )}

      {result.closingLine && (
        <AnimatedSection className="result-quote" delay={220}>
          <p className="result-quote__text">“{result.closingLine}”</p>
        </AnimatedSection>
      )}

      {result.stats?.length > 0 && (
        <AnimatedSection className="result-stats" delay={260} as="div">
          {result.stats.map((stat) => (
            <div className="result-stat" key={stat.label}>
              <div className="result-stat__row">
                <span>{stat.label}</span>
                <span className="result-stat__value">{stat.value}%</span>
              </div>
              <div className="progress-bar">
                <div className="progress-bar__fill" style={{ width: `${stat.value}%` }} />
              </div>
            </div>
          ))}
        </AnimatedSection>
      )}

      {result.disclaimer && <p className="result-disclaimer">{result.disclaimer}</p>}
    </div>
  );
}
