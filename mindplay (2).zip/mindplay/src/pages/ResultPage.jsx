import { useState } from "react";
import { useParams, useSearchParams, Navigate } from "react-router-dom";
import PageContainer from "../components/layout/PageContainer.jsx";
import Seo from "../seo/Seo.jsx";
import Button from "../components/ui/Button.jsx";
import AnimatedSection from "../components/ui/AnimatedSection.jsx";
import AdSlot from "../components/ads/AdSlot.jsx";
import ResultCard from "../components/quiz/ResultCard.jsx";
import Recommendations from "../components/recommendations/Recommendations.jsx";
import { AD_PLACEMENTS } from "../config/ads.js";
import { getTestBySlug, getResultByKey, TESTS } from "../data/tests/index.js";
import { GAMES } from "../data/games/index.js";
import { decodeStatValues } from "../engines/scoring.js";

/**
 * Página de resultado compartible: /resultado/:testSlug/:resultKey?s=...
 * Se reconstruye por completo a partir de la URL (sin estado ni servidor):
 * el testSlug localiza el test, el resultKey localiza el resultado dentro
 * de él (o el tramo correspondiente, en tests tipo "index"), y el parámetro
 * ?s= —si existe— trae las estadísticas reales calculadas en ese intento.
 */
export default function ResultPage() {
  const { testSlug, resultKey } = useParams();
  const [searchParams] = useSearchParams();
  const test = getTestBySlug(testSlug);
  const statValues = decodeStatValues(searchParams.get("s"));
  const result = getResultByKey(test, resultKey, statValues);
  const [copyFeedback, setCopyFeedback] = useState(false);

  if (!test || !result) return <Navigate to="/tests" replace />;

  // Recomendación contextual: la que trae el propio resultado si existe,
  // si no, otro test, y en último caso el primer juego disponible.
  const recommended = result.recommendedSlug
    ? result.recommendedSlug
    : (() => {
        const otherTest = TESTS.find((t) => t.slug !== test.slug);
        if (otherTest) return { type: "test", slug: otherTest.slug };
        const firstGame = GAMES[0];
        return firstGame ? { type: "game", slug: firstGame.slug } : null;
      })();

  const recommendedContent = recommended
    ? recommended.type === "test"
      ? TESTS.find((t) => t.slug === recommended.slug)
      : GAMES.find((g) => g.slug === recommended.slug)
    : null;

  const continueCtaTitle =
    result.nextStepText ||
    (recommended?.type === "game" ? "¿Ponemos a prueba algo más de ti?" : "¿Quieres descubrir otra parte de tu personalidad?");

  function buildShareText() {
    const emoji = result.emoji ? ` ${result.emoji}` : " 🧠";
    const tag = result.tagline ? ` ${result.tagline}` : "";
    return `Mi resultado en MindPlay es ${result.title.toUpperCase()}${emoji}.${tag} ¿Cuál te sale a ti?`;
  }

  function flashCopyFeedback() {
    setCopyFeedback(true);
    setTimeout(() => setCopyFeedback(false), 1800);
  }

  function copyToClipboard(text) {
    if (navigator.clipboard?.writeText) {
      return navigator.clipboard.writeText(text);
    }
    // Fallback para navegadores sin Clipboard API.
    return new Promise((resolve, reject) => {
      try {
        const textarea = document.createElement("textarea");
        textarea.value = text;
        textarea.style.position = "fixed";
        textarea.style.opacity = "0";
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();
        document.execCommand("copy");
        document.body.removeChild(textarea);
        resolve();
      } catch (err) {
        reject(err);
      }
    });
  }

  function handleShare() {
    const url = window.location.href;
    const shareText = buildShareText();
    if (navigator.share) {
      navigator.share({ title: `${result.title} — MindPlay`, text: shareText, url }).catch(() => {});
    } else {
      copyToClipboard(`${shareText} ${url}`).then(flashCopyFeedback).catch(() => {});
    }
  }

  function handleCopyLink() {
    copyToClipboard(window.location.href).then(flashCopyFeedback).catch(() => {});
  }

  return (
    <PageContainer>
      <Seo title={`${result.title} · ${test.title}`} description={result.description} />
      <div className="container">
        <ResultCard result={result} />

        <div className="result-actions">
          <Button variant="accent" onClick={handleShare}>
            Compartir mi resultado
          </Button>
          <Button variant="secondary" to="/tests">
            Hacer otro test
          </Button>
        </div>

        <div className="result-copy-row">
          <Button variant="ghost" size="sm" onClick={handleCopyLink}>
            Copiar enlace
          </Button>
          {copyFeedback && (
            <span className="result-copy-feedback" role="status">
              ¡Enlace copiado! ✅
            </span>
          )}
        </div>

        <AnimatedSection className="restart-cta" delay={40}>
          <p className="restart-cta__text">¿Te ha salido exactamente lo que esperabas?</p>
          <Button variant="secondary" to={`/tests/${test.slug}`}>
            Volver a hacer el test
          </Button>
        </AnimatedSection>

        <AdSlot placement={AD_PLACEMENTS.TEST_RESULT} size="banner" />

        {recommendedContent && (
          <AnimatedSection className="continue-cta" delay={60}>
            <h2 className="continue-cta__title">{continueCtaTitle}</h2>
            <Button
              variant="accent"
              to={recommended.type === "test" ? `/tests/${recommendedContent.slug}` : `/juegos/${recommendedContent.slug}`}
            >
              {recommended.type === "test" ? `Probar “${recommendedContent.title}”` : `Jugar a “${recommendedContent.title}”`}
            </Button>
          </AnimatedSection>
        )}

        <Recommendations excludeType="test" excludeSlug={test.slug} />
      </div>
    </PageContainer>
  );
}
