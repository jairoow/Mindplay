import { useMemo, useState } from "react";
import { calculateResult } from "../engines/scoring.js";

/**
 * Gestiona el estado de un test: pregunta actual, respuestas seleccionadas
 * y el cálculo del resultado final. No sabe nada de UI ni de rutas.
 *
 * `onComplete(result)` (opcional) se invoca de forma síncrona, en el mismo
 * evento de clic, en cuanto se responde la última pregunta — con el
 * resultado ya calculado a partir de las respuestas actualizadas. Así la
 * pantalla de resultados no depende de que un futuro render/efecto detecte
 * el cambio de estado, que es lo que hacía que, tras responder la última
 * pregunta, el test se quedara parado en ella en lugar de avanzar.
 */
export function useQuiz(test, { onComplete } = {}) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selections, setSelections] = useState({});

  const totalQuestions = test.questions.length;
  const currentQuestion = test.questions[currentIndex];
  const isLastQuestion = currentIndex === totalQuestions - 1;
  const progress = ((currentIndex + (selections[currentQuestion?.id] ? 1 : 0)) / totalQuestions) * 100;

  // Se mantiene disponible como resultado derivado (por ejemplo, para quien
  // consuma este hook sin pasar `onComplete`), pero la navegación ya no
  // depende de él.
  const result = useMemo(() => {
    if (Object.keys(selections).length < totalQuestions) return null;
    return calculateResult(test, selections);
  }, [selections, test, totalQuestions]);

  function selectOption(optionId) {
    const next = { ...selections, [currentQuestion.id]: optionId };
    setSelections(next);

    if (isLastQuestion) {
      // Última pregunta: calculamos el resultado ya mismo con las respuestas
      // completas y avisamos inmediatamente, sin esperar a un render extra.
      const finalResult = calculateResult(test, next);
      onComplete?.(finalResult);
    } else {
      setTimeout(() => setCurrentIndex((i) => i + 1), 180);
    }
  }

  function goBack() {
    setCurrentIndex((i) => Math.max(0, i - 1));
  }

  return {
    currentQuestion,
    currentIndex,
    totalQuestions,
    isLastQuestion,
    progress,
    selections,
    selectOption,
    goBack,
    result,
  };
}
